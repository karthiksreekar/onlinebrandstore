  <?php
include 'db.php';
session_start(); 
error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:page-login.php');
}
$sql = mysqli_query($conn,"SELECT * from tbl_reg where regid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
 
}

    $sql = mysqli_query($conn,"SELECT * FROM tbl_category");
    $sid=1;
    $sid = $_GET['pid'];
    

	?>
	

<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Denimology Dept.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style="margin-left: 718px;font-weight: 700;background-color: #d33b33;height: 44px; width: 159px;">
                    <i class="fa fa-user" aria-hidden="true" style="float: left; padding-left: 10px; padding-top: 4px;"></i>
                    <p class="app-sidebar__user-name"></i><?php echo $name; ?></p>
                    </button>
                      <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                         <li><a class="dropdown-item" href="profile.php">View Profile</a></li>
                         <li><a class="dropdown-item" href="cart.php">View Cart</a></li>
                         <li><a class="dropdown-item" href="logout.php">Log Out</a></li>
                        
    
                      </ul>
                </div>
                   
                  
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name" style="float: right;margin-top: 34px;">
                    <h2 style="font-family: 'Montserrat';font-weight: 600;font-size: 30px;">Denimology<br>Dept.<h2>
                    
                    </div>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="#" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="customize.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">CUSTOMIZE</a></li>
                        <li class="dropdown">
                            <a class="nav-link dropdown" data-toggle="dropdown" style="margin-right: 17px;font-size: 19px;font-weight: 700;font-family: 'Montserrat';">PRODUCTS</a>
                            <ul class="dropdown-menu">
                                <li><a href="shop.php">T-shirt</a></li>
                                <li><a href="shop.php">Shirts</a></li>
                                <li><a href="shop.php">Jeans</a></li>
                                <li><a href="shop.php">Shorts</a></li>
                                <li><a href="shop.php">Cargos</a></li>
                                <li><a href="shop.php">Hoodies</a></li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="service.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">SERVICES</a></li>
                       
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        
                        <li class="side-menu"><a href="#">
						<i class="fa fa-shopping-bag"></i>
                            
					</a></li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                    <?php  
                            $result = mysqli_query($conn,"SELECT tbl_cart.userid,tbl_cart.price,tbl_cart.total_price, tbl_cart.pro_id,tbl_products.product_name, tbl_products.product_image,tbl_products.product_company FROM tbl_cart LEFT JOIN tbl_products ON tbl_cart.pro_id = tbl_products.pro_id where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                    
                        <li>
                            
                            <a href="#" class="photo"><img src="productimages/<?php echo $raw['pro_id']; ?>/<?php echo $raw['product_image']; ?>" class="cart-thumb" alt="" /></a>
                            <h6><a href="#"> <?php echo $raw['product_name']; ?></a></h6>
                            <h6>By:<a href="#"> <?php echo $raw['product_company']; ?></a></h6>
                            
                            <p>1x - <span class="price"><?php echo $raw['price']; ?></span></p>
                        </li>
                        
                        <?php } ?>
                        
                       
                        <li class="total"> 
                          <a href="cart.php" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                        </li>
                        
                        
                        	 
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
   
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url('https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/todd-synder-denim-lead-1614352686.jpg')";>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 57px; margin-left: 110px;}">Denimology Dept.</h2>
                   
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Shop Page  -->
    <div class="shop-box-inner">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-sm-12 col-xs-12 sidebar-shop-left">
                    <div class="product-categori">
                        
                        <div class="filter-sidebar-left">
                            <div class="title-left">
                                <h3>Categories</h3>
                            </div>
                            <div class="list-group list-group-collapse list-group-sm list-group-tree" id="list-group-men" data-children=".sub-men">
                            <a class="nav-link"  href="shop.php?pid=0" role="tab" aria-controls="" aria-selected="true">Home</a>
                                <?php while ($row = mysqli_fetch_array($sql)){ ?>
						<a class="nav-link" id="<?php echo $row['id']; ?>" href="shop.php?pid=<?php echo $row['id']; ?>" role="tab" aria-controls="<?php echo $row['id']; ?>" aria-selected="true"><?php echo $row['category_name']; ?></a>
                        <?php } ?>
                            </div>
                        </div>
        
                        <div class="filter-brand-left">
                            
                            <div class="brand-box">
                                
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-xl-9 col-lg-9 col-sm-12 col-xs-12 shop-content-right">
                    <div class="right-product-box">
                        <div class="product-item-filter row">
                        <h2 style="padding-left: 139px;font-size: 30px;font-family: 'Montserrat';">People will Stare.Make it worth their while</h2>
                           
                           
                        </div>
                        <br>
                        <?php 
                        if(($sid)==0){
                        include 'carousel.php';
                        }else{
                        ?>

                        <div class="row product-categorie-box">
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                                    <div class="row">
                                    <?php  
                            $result = mysqli_query($conn,"SELECT * FROM tbl_products where category='$sid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                        <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                                        <form method="post" action="shop.php?pid=<?php echo $sid; ?>">
                                            <div class="products-single fix">
                                                <div class="box-img-hover">
                                                   
                                                    <img src="productimages/<?php echo $raw['pro_id']; ?>/<?php echo $raw['product_image']; ?>" class="img-fluid" alt="Image" style="height: 368px;width: 304px;">
                                                   
                                                </div>
                                                <div class="why-text">
                                                    <h4><?php echo $raw['product_name']; ?></h4>
                                                    <h5><?php echo $raw['price']; ?></h5>
                                                    <input type="hidden" name="productid" value="<?php echo $raw['pro_id']; ?>"> 
                                                    <a class="nav-link" id="<?php echo $raw['pro_id']; ?>" href="listbox.php?aid=<?php echo $raw['pro_id']; ?>" role="tab" aria-controls="<?php echo $raw['pro_id']; ?>" aria-selected="true">View product</a>
                                                </div>
                                            </div>
                                            </form>
                                        </div>
                                        <?php } } ?>	
                                    </div>
                                </div>
                                
                                     
                             
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Shop Page -->

    <!-- End Instagram Feed  -->


    <!-- Start Footer  -->
   <?php include 'footer.php' ?>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>