
<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{
	$email=$_POST['username'];
	$pass=$_POST['password'];
 
$query="SELECT * FROM `tbl_login` WHERE username='$email' and `password`='$pass'";
$result=mysqli_query($conn,$query) or die("error".mysqli_error($link));
$rowcount=mysqli_num_rows($result); 
if($rowcount>0)
{
  while($row=mysqli_fetch_assoc($result)){
	if($row['role']==0)
	{
		$_SESSION['UserID'] = $row['loginid'];
	  header("location:admin.php");
	}
	 else if($row['role']==3){
		$_SESSION['UserID'] = $row['loginid'];
		header("location:shop.php");
   }
   else if($row['row']==2){
		$_SESSION['UserID'] = $row['loginid'];
		header("location:designer.php");
	 }
	 else {
		echo "<script>alert('Username and password are incorrect')</script>";
		echo "<script>window.location='index.php'</script>";
		} 
}
 }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css_log/owl.carousel.min.css">
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css_log/style.css">

    <title>Log In</title>

  </head>
  <body>
  

  
  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-md-6 order-md-2">
          <img src="images/logo.jpg" alt="Image" class="img-fluid" style="height: 379px;">
          
        </div>
        
        
        <div class="col-md-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="mb-4">
              <h3><strong>Denimlology Dept.</strong></h3>
              <p class="mb-4">Custom – Character – Class.</p>
            </div>
            <form action="" name="myForm" onsubmit="return validateForm()" method="POST">
              <div class="form-group first">
              
                  <label for="username">EMAIL</label>
                
                <input type="text" class="form-control" name="username" id="username">

              </div>
              <div class="form-group last mb-4">
              <label for="password">PASSWORD</label>
                <input type="password" class="form-control" name="password" id="password">
                
              </div>
              <div class="form-floating">
                  <select class="form-select" id="floatingSelect" aria-label="Floating label select example" style="border: none;border-bottom-color: #ccc;border-bottom: 1px solid; font-size: 12px;display: block;color: #b3b3b3;width: 100%;margin-bottom: 16px;">
                  <option name="role" selected >USER TYPE</option>
                  <option value="1" style="font-size:12px">CUSTOMER</option>
                  <option value="2">ADMIN</option>
                  <option value="3">DESIGNER</option>
                  </select>
                 
               </div>
              
              
 
              <input type="submit" name="submit" value="Log In" class="btn text-white btn-block btn-primary">
              
            
            </form>
            <script>  
					
						</script>
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
    <span class="ml-auto"><a href="signup.php" style="margin-left: 1017px;margin-left: 1071px; font-size: 18px; font-weight: 800;">New User?Register Here.</a></span> 
  </div>

  
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>