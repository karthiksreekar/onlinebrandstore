<?php
include 'db.php';
session_start();
//error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from tbl_reg where regid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
 
}

if(isset($_POST['order'])){
    $total=$_POST['total'];
	$car2 = mysqli_query($conn,"SELECT * FROM `tbl_cart` where userid=$uid");
    while($row = mysqli_fetch_array($car2))  { 
    $cartid = $_POST['id'];
	$order="INSERT INTO `tbl_order`(`userid`, `cartid`, `price`,`status`) VALUES ('$uid', '$cartid', '$total','placed')";
	$or1=mysqli_query($conn,$order);

    }
    
    echo "<script>alert('Your Order have been placed Successfully!!');</script>";
	
	echo"<script>window.location='final.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Denimology Dept.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                       
                    </div>
                </div>
                <
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="shop.php"><img src="images/logo.jpg" style="height: 124px;width: 147px;" class="logo" alt=""></a>
                    <div class="brand_name" style="float: right;margin-top: 34px;">
                    <h2 style="font-size: 30px;font-family: 'Montserrat';font-weight: 600;">Denimology<br>Dept.<h2>
                    
                    </div>
                    
                
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="index.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="shop.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                        <li class="nav-item"><a class="nav-link" href="customize.pho" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Customize</a></li>
                        <li class="nav-item"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Cart</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Log out</a></li>
                        
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
               
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
   
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url('https://www.retrostyling.co.uk/site/wp-content/uploads/2017/10/denim_rail_edited.jpg');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 45px;font-weight: 900;">Checkout</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="shop.php">Shop</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Cart  -->
    <div class="cart-box-main">
        <div class="container">
           
            <div class="row">
            
                <div class="col-sm-6 col-lg-6 mb-3">
                    <div class="checkout-address">
                        <div class="title-left">
                            <h3>Billing address</h3>
                        </div>
                        
                        <form class="needs-validation" novalidate>
                            <div class="row">
                                
                            </div>
                            <div class="mb-3">
                            <?php
                $result = mysqli_query($conn,"SELECT * FROM tbl_reg where regid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                <label for="username">Username </label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="username" placeholder="<?php echo $raw['name']; ?>" readonly>
                                   
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="email">Email Address </label>
                                <input type="email" class="form-control" id="email" placeholder="<?php echo $raw['email']; ?>" readonly>
                                
                            </div>
                            <div class="mb-3">
                                <label for="email">Contact Number </label>
                                <input type="email" class="form-control" id="phone" placeholder="<?php echo $raw['phone']; ?>" readonly>
                                
                            </div>
                            <div class="mb-3">
                                <label for="address">Address </label>
                                <input type="text" class="form-control" id="address" placeholder="<?php echo $raw['address']; ?>" readonly>
                            
                            </div>
                                <?php } ?>
                            
                            <div class="row">
                                <div class="col-md-5 mb-3">
                                   
                                  
                                </div>
                                <div class="col-md-4 mb-3">
                                   
                                </div>
                                <div class="col-md-3 mb-3">
                                    
                                </div>
                            </div>
                            </form>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 mb-3">
                <form action="" method="POST">
                    <div class="row">
                       
                        <div class="col-md-12 col-lg-12">
                            <div class="odr-box">
                                <div class="title-left">
                                    <h3>Shopping cart</h3>
                                </div>
                                <div class="rounded p-2 bg-light">
                                    <div class="media mb-2 border-bottom">
                                    <?php
                                $result = mysqli_query($conn,"SELECT tbl_cart.id,tbl_cart.price,tbl_cart.quantity,tbl_cart.total_price, tbl_cart.pro_id, tbl_cart.size,tbl_products.product_name, tbl_products.product_image,tbl_products.product_company FROM tbl_cart LEFT JOIN tbl_products ON tbl_cart.pro_id = tbl_products.pro_id where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                                        <div class="media-body"> <a href="cart.php"> <?php echo $raw['product_name']; ?></a>
                                        <input type="hidden" name="id" value="<?php echo $raw['id']; ?>">
                                        
                                            <div class="small text-muted">Price: <?php echo $raw['price']; ?> <span class="mx-2">|</span> Qty: <?php echo $raw['quantity']; ?>  <span class="mx-2">|</span> Size: <?php echo $raw['size']; ?><span class="mx-2">|</span> Subtotal: <?php echo $raw['total_price']; ?> </div>
                                        </div>
                                    </div>
                                <?php } ?>
                                   
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-12">
                            <div class="order-box">
                                <div class="title-left">
                                    <h3>Your order</h3>
                                </div>
                                <div class="d-flex">
                                    
                                   
                                </div>
                              
                            
                          
                               
                                
                                <div class="d-flex gr-total">
                                    <h5>Grand Total</h5>
                                    <?php
                                    $qq = mysqli_query($conn,"SELECT SUM(total_price) FROM `tbl_cart` WHERE userid='$uid'");
                                    while($er=mysqli_fetch_array($qq)){
                                    ?>
                                    <div class="ml-auto h5"><p>RS:</p> <input type="text" name="total" value="<?php echo $er['SUM(total_price)'];?>" style="border:none"> </div>
                                    <?php } ?>
                                </div>
                                <hr> </div>
                        </div>
                        <div style=""><input type="submit" style="height: 48px;font-weight: 500; font-size: 19px" name="order" value="Place Order"class="ml-auto btn hvr-hover"></div>
                    </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
    <!-- End Cart -->

    <!-- Start Instagram Feed  -->
   
    <!-- End Instagram Feed  -->

<?php include 'footer.php' ?>
    <!-- Start Footer  -->
   
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>