<?php
include 'db.php';
session_start();
//error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:page-login.php');
}
?>
<?php

if(isset($_POST['remove'])){

$cartid = $_POST['id'];
$quan = $_POST['quantity'];
$sqlls = "DELETE from tbl_cart where id=$cartid";
mysqli_query($conn,$sqlls);
echo"<script>alert('Item Removed');</script>";
echo"<script>window.location='cart.php';</script>";
}

if(isset($_POST['update'])){
    $price = $_POST['totalprice'];
    $quan = $_POST['quantity'];
    $cartid = $_POST['id'];
    if($quan==0){
        $sqlls = "DELETE from tbl_cart where id=$cartid";
      mysqli_query($conn,$sqlls);
     echo"<script>alert('Item Removed');</script>";
     echo"<script>window.location='cart.php';</script>";

    }
    else{
    $sqll = "UPDATE tbl_cart SET quantity=$quan,total_price=$price";
    mysqli_query($conn,$sqll);
    
    echo"<script>alert('Cart Updated');</script>";
    echo"<script>window.location='cart.php';</script>";
    }
}

if(isset($_POST['order'])){
    
	$car2 = mysqli_query($conn,"SELECT * FROM `tbl_cart` where userid=$uid");
    while($row = mysqli_fetch_array($car2))
    {
	$quantity=$row['quantity'];
    $price=$row['total_price'];
    $cartid = $_POST['id'];
	$order="INSERT INTO `tbl_order`(`userid`, `cartid`, `price`) VALUES ('$uid', '$cartid', '$price')";
	$or1=mysqli_query($conn,$order);

	}
	echo "<script>alert('item ordered successfully');</script>";
	echo"<script>window.location='checkout.php';</script>";
}

?>

<script>
function remove()
{
if(confirm("Do you want to remove this item"))
{
	return true;
}
else{
	return false;
}
}                      
 </script>


<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Denimology Dept.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        <div id="offer-box" class="carouselTicker">
                            <ul class="offer-box">
                                <li>
                                    <i class="fab fa-opencart"></i> The Man Company
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stay in Fashion
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> The Customizable Brand Store
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Off 50%! Shop Now
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> The Customizable Brand Store
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stay in Fashion
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stand Out!!
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> The Man Company
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
             
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt="" style="height: 124px;width: 147px;"></a>
                    <div class="brand_name">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">Denimology<br>Dept.<h2>
                    
                    </div>
                    
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="index.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Home</a></li>
                        <li class="dropdown megamenu-fw">
                        <li class="nav-item"><a class="nav-link" href="#"style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Products</a></li>
                            
                        </li>
                        
                        <li class="nav-item"><a class="nav-link" href="#" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                        <li class="nav-item"><a class="nav-link" href="#" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Customize</a></li>
                        <li class="nav-item"><a class="nav-link" href="#" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Contact </a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
               
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
           
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
 
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url('https://www.thefashionisto.com/wp-content/uploads/2014/07/fvb_denim001.jpg');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 45px;font-weight: 900; padding-left: 80px;">My Cart</h2>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Cart  -->
    <div class="cart-box-main">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-main table-responsive">
                    <form name="cart" method="POST">
  
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Images</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                             
                            	<?php
                                $sql2 = "SELECT * from tbl_cart where userid=$uid";
                                $price=mysqli_query($conn,$sql2);
                                $cart = mysqli_fetch_array($price);
                                $amount = $cart['price'] * $cart['quantity'] ;			
                                $result = mysqli_query($conn,"SELECT tbl_cart.id,tbl_cart.price,tbl_cart.quantity,tbl_cart.total_price, tbl_cart.pro_id,tbl_products.product_name, tbl_products.product_image,tbl_products.product_company FROM tbl_cart LEFT JOIN tbl_products ON tbl_cart.pro_id = tbl_cart.pro_id where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                            
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="productimages/<?php echo $raw['pro_id']; ?>/<?php echo $raw['product_image']; ?>" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                    <input type="hidden" name="id" value="<?php echo $raw['id']; ?>">
                                        <a href="#">
                                        <?php echo $raw['product_name']; ?>
								</a>
                                    </td>
                                    <td class="price-pr">
                                        <input type="text" name="price" value="<?php echo $raw['price']; ?>" style="border: none;ont-family: 'Quattrocento Sans', sans-serif;color:#666666">
                                    </td>
                                    <td class="quantity-box"><input type="number" name="quantity" size="4" value="<?php echo $raw['quantity']; ?>" min="0" step="1" class="c-input-text qty text"></td>
                                    <td class="total-pr">
                                    <input type="text" name="totalprice" value="<?php echo $amount ?>" style="border: none;ont-family: 'Quattrocento Sans', sans-serif;color:#666666">
                                    </td>
                                    <td class="remove-pr">
                                        <button name="remove" onclick="return remove()" style="border: none;background-color: #fff;">
									<i class="fas fa-times"></i>
								</button>
                                
                                    </td>
                                 
                                </tr>
                                <?php }  ?>
                               
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>

            <div class="row my-5">
                
                <div class="col-lg-6 col-sm-6">
                    <div class="update-box">
                        <input value="Update Cart" type="submit" name="update">
                    </div>
                </div>
                <div class="col-lg-6 col-sm-6">
                    <div class="update-box">
                        <input value="Place Order" type="submit" name="order">
                    </div>
                </div>
            </div>
            </form>
            

          
        </div>
    </div>
    <!-- End Cart -->

    <!-- Start Instagram Feed  -->
    <div class="instagram-box">
        <div class="main-instagram owl-carousel owl-theme">
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-01.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-02.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-03.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-04.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-05.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-06.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-07.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-08.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-09.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-05.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Instagram Feed  -->


    <!-- Start Footer  -->
    <footer>
        <div class="footer-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-widget">
                            <h4>About ThewayShop</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                </p>
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link">
                            <h4>Information</h4>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Customer Service</a></li>
                                <li><a href="#">Our Sitemap</a></li>
                                <li><a href="#">Terms &amp; Conditions</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Delivery Information</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="footer-link-contact">
                            <h4>Contact Us</h4>
                            <ul>
                                <li>
                                    <p><i class="fas fa-map-marker-alt"></i>Address: Michael I. Days 3756 <br>Preston Street Wichita,<br> KS 67213 </p>
                                </li>
                                <li>
                                    <p><i class="fas fa-phone-square"></i>Phone: <a href="tel:+1-888705770">+1-888 705 770</a></p>
                                </li>
                                <li>
                                    <p><i class="fas fa-envelope"></i>Email: <a href="mailto:contactinfo@gmail.com">contactinfo@gmail.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer  -->

    <!-- Start copyright  -->
    <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2018 <a href="#">ThewayShop</a> Design By :
            <a href="https://html.design/">html design</a></p>
    </div>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>