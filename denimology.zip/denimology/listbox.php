<?php 
  include 'db.php';
session_start(); 
error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from tbl_reg where regid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
 
}
  $sid=1;
  $sid = $_GET['aid'];
  $sql = mysqli_query($conn,"SELECT * FROM tbl_products where pro_id='$sid'");

  if(isset($_POST['cart'])){
    $productid = intval($_POST['productid']);
    $size = $_POST['size'];
    $quantity=$_POST['quantity'];
    $product = "SELECT * from tbl_products where pro_id=$productid";
    $products = mysqli_query($conn,$product);
    $row = mysqli_fetch_assoc($products); 
    $totalprice=0;
    $price=$row['price'];
    $valid=mysqli_query($conn,"select * from tbl_cart where userid='$uid' and pro_id='$productid'");
    if(mysqli_num_rows($valid)>0)
    {
     echo "<script>alert('product already exists');</script>";
     echo "<script>location=cart.php</script>";
  
    }else{
    
       $totalprice=$quantity*$price;
       $sql2 = "INSERT INTO tbl_cart(userid,pro_id,quantity,size,price,total_price) VALUES($uid,$productid,$quantity,'$size',$price,$totalprice)";
       mysqli_query($conn,$sql2);
    }
   

    echo "<script>location='cart.php'</script>";
      
    }

?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Denimology Dept.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        
                    </div>
                </div>
               
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt=""  style="height: 124px;width: 147px;"></a>
                    <div class="brand_name"  style="float: right;margin-top: 34px;">
                    <h2 style="margin-top: 10px;font-family: 'Montserrat';font-weight: 600;">Denimology<br>Dept.<h2>
                    
                    </div>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="index.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="customize.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">CUSTOMIZE</a></li>
                        <li class="nav-item">
                            <a class="nav-link" href="shop.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">SHOP</a>
                            
                        </li>
                        <li class="nav-item"><a class="nav-link" href="service.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">SERVICES</a></li>
             
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                       
                        <li class="side-menu"><a href="#">
						<i class="fa fa-shopping-bag"></i>
                            
					</a></li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                    <?php  
                            $result = mysqli_query($conn,"SELECT tbl_cart.userid,tbl_cart.price,tbl_cart.total_price, tbl_cart.pro_id,tbl_products.product_name, tbl_products.product_image,tbl_products.product_company FROM tbl_cart LEFT JOIN tbl_products ON tbl_cart.pro_id = tbl_products.pro_id where userid='$uid'");
                                while ($raw = mysqli_fetch_array($result)){ ?>
                    
                        <li>
                            
                            <a href="#" class="photo"><img src="productimages/<?php echo $raw['pro_id']; ?>/<?php echo $raw['product_image']; ?>" class="cart-thumb" alt="" /></a>
                            <h6><a href="#"> <?php echo $raw['product_name']; ?></a></h6>
                            <h6>By:<a href="#"> <?php echo $raw['product_company']; ?></a></h6>
                            
                            <p>1x - <span class="price"><?php echo $raw['price']; ?></span></p>
                        </li>
                        
                        <?php } ?>
                        
                       
                        <li class="total"> 
                          <a href="cart.php" class="btn btn-default hvr-hover btn-cart">VIEW CART</a>
                        </li>
                        
                        
                        	 
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <h2 style="font-size: 45px;font-weight: 900; padding-left: 80px;">Denimology Dept.</h2>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Shop</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Shop Detail  -->
    <div class="shop-detail-box-main">
        <div class="container">
        <form action="" method="POST">
            <?php while ($row = mysqli_fetch_array($sql)){ ?>
            <div class="row">
         
                <div class="col-xl-5 col-lg-5 col-md-6">
                    <div id="carousel-example-1" class="single-product-slider carousel slide" data-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active"> <img class="d-block w-100" src="productimages/<?php echo $row['pro_id']; ?>/<?php echo $row['product_image']; ?>" alt="First slide"> </div>
                           
                        </div>
                      
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-6">
              
                
                    <div class="single-product-details">
                        <h2><?php echo $row['product_name']; ?></h2>
                        <h5>RS: <?php echo $row['price']; ?> </h5>
                       
                                <h4>Description</h4>
                                <p><?php echo $row['description']; ?></p>
                                <ul>
                                <input type="hidden" name="productid" value="<?php echo $row['pro_id']; ?>"> 
                                    <li>
                                    <div class="form-group size-st">
                                    <label class="size-label">Size</label>
                                    <select id="size" name="size" class="form-control" required>
									<option value="select" selected disabled>size</option>
									<option value="small">S</option>
									<option value="medium">M</option>
									<option value="large">L</option>
									<option value="xlarge">XL</option>
									<option value="xxlarge">XXL</option>
									<option value="3xl">3XL</option>
									<option value="4xl">4XL</option>
								</select>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="form-group quantity-box">
                                            <label class="control-label">Quantity</label>
                                            <input class="form-control" name="quantity" value="1" min="1" max="20" type="number">
                                        </div>
                                    </li>
                                </ul>

                                <div class="price-box-bar">
                                    <div class="cart-and-bay-btn">
                                    
                                    <input type="submit" name="cart" value="Add to Cart" style="height: 43px;color: #fff;  background: #d33b33; border-radius: 5px;width: 98px;font-size: initial;font-weight: 900;}">
                                    


                                     
                                    
                                    </div>
                                </div>
                                <button name="view cart"  style="height: 43px;color: #fff;  background: #d33b33; border-radius: 5px;width: 98px;font-size: initial;font-weight: 900;}"><a href="cart.php" style="color:#fff">View Cart</a></button>

                             
                                
                    </div>
                 

                </div>
                <?php } ?>
                </form>
            
            </div>
           
       
    </div>
    <br>
    <br>
    <br>
    <!-- End Cart -->

   


    <!-- Start Footer  -->
    <?php include 'footer.php' ?>
    <!-- End Footer  -->

    <!-- Start copyright  -->
   
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>