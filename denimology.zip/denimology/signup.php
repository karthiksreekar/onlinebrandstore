 <?php
include 'db.php';

if(isset($_POST['submit'])){
 
	$name=$_POST['name'];
    $email=$_POST['email'];
	$pass=$_POST['password'];
	$phn=$_POST['phone'];
    $add=$_POST['address'];
    $valid=mysqli_query($conn,"select * from tbl_reg where email='$email'");
    if(mysqli_num_rows($valid)>0)
    {
     echo "<script>alert('email already exists');</script>";
     echo "<script>location=cart.php</script>";
  
    }else{
   ?>
   <script>alert("Succesfully registered");</script>
   <?php
    
	$sql = mysqli_query($conn,"INSERT INTO `tbl_login`(`username`, `password`, `role`, `status`) VALUES ('$email','$pass',3,1)");
    $rid = mysqli_insert_id($conn);
	$sql = mysqli_query($conn,"INSERT INTO `tbl_reg`(`regid`,`name`, `email`, `phone`,`address`) VALUES ('$rid','$name','$email','$phn','$add')");
}
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Denimology Dept.</title>
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
   
    <link rel="stylesheet" href="css_sign/style.css">
    <script>
function registration()
      {
 
          var name= document.getElementById("name").value;
          var email= document.getElementById("email").value;
          var number= document.getElementById("phone").value;
          var address= document.getElementById("address").value;
          var pwd= document.getElementById("password").value;
          var cpwd= document.getElementById("repass").value;
         
          //email id expression code
          var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
          var letters = /^[A-Za-z]+$/;
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          var phoneno = /^\d{10}$/;
         
 if(name=='')
          {
              alert('Please enter your name');
              return false;
          }
          else if(!letters.test(name))
          {
              alert('Name field required only alphabet characters');
              return false;
          }

          else if(email=='')
          {
              alert('Please enter your user email id');
              return false;
          }
          else if (!filter.test(email))
          {
              alert('Enter the e-mail format correctly');
              return false;
          }
 else if(number=='')
          {
              alert('Please enter your number');
              return false;
          }
 else if(!phoneno.test(number))
          {
              alert('Enter number correctly');
              return false;
          }
 
          
          else if(password=='')
          {
              alert('Please enter Password');
              return false;
          }
          else if(address=='')
          {
              alert('Please enter Address');
              return false;
          }
          else if(repass=='')
          {
              alert('Enter Confirm Password');
              return false;
          }
          else if(!pwd_expression.test(pwd))
          {
              alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
              return false;
          }
          else if(pwd != cpwd)
          {
              alert ('Password not Matched');
              return false;
          }
          else if(document.getElementById("password").value.length < 6)
          {
              alert ('Password minimum length is 6');
              return false;
          }
          else if(document.getElementById("repass").value.length > 12)
          {
              alert ('Password max length is 12');
              return false;
          }
          else
          {                            
               
                 return true;
               
          }
      }
      </script>
</head>
<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Sign up</h2>
                        <form method="POST" action="signup.php" class="register-form" id="register-form"  onsubmit="return registration()" >
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name"/>
                                
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"/>
                              
                            </div>
                            <div class="form-group">
                                <label for="phone"><i class="zmdi zmdi-phone"></i></label>
                                <input type="text" name="phone" id="phone" placeholder="Contact No"/>
                              
                            </div>
                           
                            <div class="form-group">
                                <label for="uname"><i class="zmdi zmdi-pin-drop"></i></label>
                                <input type="text" name="address" id="address" placeholder="Address"/>
                              
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="password" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="repass" id="repass" placeholder="Repeat your password"/>
                            </div>
                          
                            <div class="form-group form-button">
                                <input type="submit" name="submit" id="submit" class="form-submit" value="Register"/>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/logo.jpg" alt="sing up image" style="margin-top: 105px;"></figure>
                        <a href="login.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

