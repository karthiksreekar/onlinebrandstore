<!doctype html>
<html lang="en">
  <head>
  	<title>Denimology Dept</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="css_carousel/css/owl.carousel.min.css">
    <link rel="stylesheet" href="css_carousel/css/owl.theme.default.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/4.5.6/css/ionicons.min.css">
		<link rel="stylesheet" href="css_carousel/css/style.css">
  </head>
  <body>
		
		<section class="ftco-section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						
					</div>
					<div class="col-md-12">
						<div class="featured-carousel owl-carousel">
							<div class="item">
								<div class="work-wrap d-md-flex">
									<div class="img order-md-last" style="background-image: url('https://cdn.shopify.com/s/files/1/0516/4538/2842/products/9349457974146_5172_1024x1024.jpg?v=1630644026');"></div>
									<div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center">
										<div class="desc w-100">
											<h2 class="mb-4">Define <br> Your Budget</h2>
											<p class="h5">Denimology Dept.</p>
											<p class="h5 mb-4">Stay in fashion.</p>
											<div class="row justify-content-end">
												<div class="col-xl-8">
													<p>People will stare,make it worth their while</p>
												</div>
											</div>
											<p>
												<button type="button" class="btn btn-outline-dark mb-2 py-3 px-4">Shop</button>
												
											</p>
										</div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="work-wrap d-md-flex">
									<div class="img order-md-last" style="background-image: url('https://prettypoisonbar.com/wp-content/uploads/2019/11/DSCF2444-2-scaled.jpg');"></div>
									<div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center">
										<div class="py-md-5">
											<h2 class="mb-4">Cool<br>Brands</h2>
											<p class="h5">Denimology Dept.</p>
											<p class="h5 mb-4">Stay in fashion</p>
											<div class="row justify-content-end">
												<div class="col-xl-8">
													<p>people will stare,make it worth their while</p>
												</div>
											</div>
											<p>
												<button type="button" class="btn btn-outline-dark mb-2 py-3 px-4">Shop </button>
				
											</p>
										</div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="work-wrap d-md-flex">
									<div class="img order-md-last" style="background-image: url('http://levistrauss.com/wp-content/uploads/2016/04/Levis-We-Are-501_Matt_hero.jpg');"></div>
									<div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center">
										<div class="py-md-5">
											<h2 class="mb-4">Cool <br> Looks</h2>
											<p class="h5">Denimology Dept.</p>
											<p class="h5 mb-4">Stay in fashion</p>
											<div class="row justify-content-end">
												<div class="col-xl-8">
													<p>people will stare,make it worth their while</p>
												</div>
											</div>
											<p>
												<button type="button" class="btn btn-outline-dark mb-2 py-3 px-4">Shop</button>
											</p>
										</div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="work-wrap d-md-flex">
									<div class="img order-md-last" style="background-image: url('https://www.thefashionisto.com/wp-content/uploads/2017/02/Levis-501-Skinny-Jeans-Hillman-Wash.jpg');"></div>
									<div class="text text-left text-lg-right p-4 px-xl-5 d-flex align-items-center">
										<div class="py-md-5">
											<h2 class="mb-4">Good<br>Vibes</h2>
											<p class="h5">Denimology Dept.</p>
											<p class="h5 mb-4">Stay in fashion</p>
											<div class="row justify-content-end">
												<div class="col-xl-8">
													<p>people will stare,make it worth their while</p>
												</div>
											</div>
											<p>
												<button type="button" class="btn btn-outline-dark mb-2 py-3 px-4">Shop</button>
												
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

    <script src="css_carousel/js/jquery.min.js"></script>
    <script src="css_carousel/js/popper.js"></script>
    <script src="css_carousel/js/bootstrap.min.js"></script>
    <script src="css_carousel/js/owl.carousel.min.js"></script>
    <script src="css_carousel/js/main.js"></script>
  </body>
</html>