<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Denimology Dept</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        <div id="offer-box" class="carouselTicker">
                            <ul class="offer-box">
                                <li>
                                    <i class="fab fa-opencart"></i> The Customizable Brand Store
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> 50% - 80% off on Fashion
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stay In Fashion
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stand Out!!
                                </li>
                                 <li>
                                    <i class="fab fa-opencart"></i> Shop Now 
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stay In Fashion
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Stay In Fashion
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> The Customizable Brand Store
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                   
    
                    <div class="our-link">
                        <ul>
                          
                            <li><a href="#">Our location</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt="" style="height: 124px;width: 147px;"></a>
                    <div class="brand_name" style="float: right;margin-top: 34px;">
                    <h2 style="font-size: 27px;font-family: 'Montserrat';font-weight: 600;font-size: 30px;">Denimology<br>Dept.<h2>
                    
                    </div>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item active"><a class="nav-link" href="index.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">HOME</a></li>
                        
                        <li class="nav-item"><a class="nav-link" href="login.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">LOG IN </a></li>
                        <li class="nav-item"><a class="nav-link" href="signup.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">REGISTER</a></li>
                        <li class="nav-item"><a class="nav-link" href="service.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">SERVICES</a></li>
                        <li class="nav-item"><a class="nav-link" href="about.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">ABOUT</a></li>
                        
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
                
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
          
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    <!-- End Top Search -->

    <!-- Start Slider -->
    <div id="slides-shop" class="cover-slides">
        <ul class="slides-container">
            <li class="text-left">
                <img src="https://www.thetimes.co.uk/imageserver/image/%2Fmethode%2Fsundaytimes%2Fprod%2Fweb%2Fbin%2Fd545bb24-54c3-11eb-833a-13260846b8df.png?crop=1642%2C924%2C0%2C0" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Denimology Dept</strong></h1>
                            <p class="m-b-40">“Remind yourself. Nobody built like you, you design yourself.”<br></p>
                            <p><a class="btn hvr-hover" href="login.php">Shop Now</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-center">
                <img src="https://images.askmen.com/1080x540/2017/01/20-012724-things_any_man_can_do_to_look_better.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Denimology Dept</strong></h1>
                            <p class="m-b-40">Fashion is an art. You express who you are through what you’re wearing.</p>
                            <p><a class="btn hvr-hover" href="login.php">Shop Now</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-right">
                <img src="http://cdn.shopify.com/s/files/1/1532/8355/articles/blog_hero.jpg?v=1618240134" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>Welcome To <br> Denimology Dept.</strong></h1>
                            <p class="m-b-40">Clothes With Method</p>
                            <p><a class="btn hvr-hover" href="login.php">Shop Now</a></p>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
        <div class="slides-navigation">
            <a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            <a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
        </div>
    </div>
    <!-- End Slider -->

    <!-- Start Categories  -->
    <div class="categories-shop" style="margin-left: 69px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="shop-cat-box" style="width: 269px; height: 336px;">
                        <img class="img-fluid" src="https://i1.adis.ws/i/boohooamplience/mzz20061_black_xl_3?$product_image_main_mobile$&fmt=webp" alt="" />
                        <a class="btn hvr-hover" href="login.php">T-shirts</a>
                    </div>
                    <div class="shop-cat-box"  style="width: 269px; height: 336px;">
                        <img class="img-fluid" src="https://m.media-amazon.com/images/I/61ND+TA43pL._UY550_.jpg" alt="" />
                        <a class="btn hvr-hover" href="login.php">Shirts</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="shop-cat-box"  style="width: 269px; height: 336px;">
                        <img class="img-fluid" src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/everlane-3-1631570236.jpg?crop=0.502xw:1.00xh;0.250xw,0&resize=640:*" alt="" />
                        <a class="btn hvr-hover" href="login.php">Jeans</a>
                    </div>
                    <div class="shop-cat-box"  style="width: 269px; height: 336px;">
                        <img class="img-fluid" src="https://i.pinimg.com/564x/ab/5a/57/ab5a57a0ecbe6ae8d88c47accc30d8c2.jpg" alt="" />
                        <a class="btn hvr-hover" href="login.php">Shorts</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="shop-cat-box"  style="width: 269px; height: 336px;">
                        <img class="img-fluid" src="https://rukminim1.flixcart.com/image/714/857/kjvrdzk0/cargo/g/5/g/32-trj-09dusty-olive-woodland-original-imafzcz9d4gcy67c.jpeg?q=50" alt="" />
                        <a class="btn hvr-hover" href="login.php">Cargos</a>
                    </div>
                    <div class="shop-cat-box"  style="width: 269px; height: 336px;">
                        <img class="img-fluid" src="https://img.guess.com/image/upload/f_auto,q_auto,fl_strip_profile,w_392,c_scale/v1/NA/Style/ECOMM/M2RQ15KAVQ2-G018" alt="" />
                        <a class="btn hvr-hover" href="login.php">Hoodies</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Categories -->

    <!-- Start Products  -->
   
    <!-- End Products  -->

    <!-- Start Blog  -->
    <div class="latest-blog">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="title-all text-center">
                        <h1>latest blog</h1>
                        <p>Denim and Denim Only.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4 col-xl-4">
                    <div class="blog-box">
                        <div class="blog-img">
                            <img class="img-fluid" src="images/blog-img.jpg" alt="" />
                        </div>
                        <div class="blog-content">
                            <div class="title-blog">
                                <h3>Denim - Buy Denim Clothing for Men Online in India.</h3>
                                <p>Pair your denim pants with tees, shirts, jackets, the options are endless. An evergreen outfit, say yes to denims </p>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-4">
                    <div class="blog-box">
                        <div class="blog-img">
                            <img class="img-fluid" src="images/blog-img-01.jpg" alt="" />
                        </div>
                        <div class="blog-content">
                            <div class="title-blog">
                                <h3>Denim Accessories for men for that rigid look</h3>
                                <p>Leather and Denim are a deadly Combination.Wear em' with your faviourite outfits to uplift your fashion  </p>
                            </div>
                           
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-4">
                    <div class="blog-box">
                        <div class="blog-img">
                            <img class="img-fluid" src="images/blog-img-02.jpg" alt="" />
                        </div>
                        <div class="blog-content">
                            <div class="title-blog">
                                <h3>Build Your Own Brand  </h3>
                                <p> you can create custom clothes using your own personal designs. Embrace your creative side and personalize custom clothing </p>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Blog  -->


    <!-- Start Instagram Feed  -->
    <div class="instagram-box">
        <div class="main-instagram owl-carousel owl-theme">
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-01.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-02.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-03.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-04.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-05.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-06.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-07.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-08.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-09.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-05.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Instagram Feed  -->

    

    <!-- Start Footer  -->
   <?php include 'footer.php' ?>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>