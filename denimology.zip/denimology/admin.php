<?php
include 'db.php';
session_start(); 
error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from tbl_login where loginid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
 
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Denimology Dept.</title>
    <link rel="stylesheet" type="text/css" href="css_admin/style.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css"
        integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
        <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo.jpg">

</head>

<body>
    <div class="container">
        <div class="navigation" style=" background: black">
            <ul>
                <li>
                    <a href="#">
                      
                        <span class="title">
                            <h2>Denimology Dept </h2>
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="insert_product.php">
                        <span class="icon"><i class="fa fa-plus" aria-hidden="true"></i></span>
                        <span class="title">Add Products</span>
                    </a>
                </li>
                <li>
                    <a href="insert_category.php">
                        <span class="icon"><i class="fa fa-plus" aria-hidden="true"></i></span>
                        <span class="title">Add Category</span>
                    </a>
                </li>
                <li>
                    <a href="view-orders.php">
                        <span class="icon"><i class="fa fa-plus" aria-hidden="true"></i></span>
                        <span class="title">View Orders</span>
                    </a>
                </li>
               
            </ul>
        </div>

        <div class="main">
            <div class="topbar">
                <div class="toggle" onclick="toggleMenu()"></div>
                <div class="search">
               

                </div>
                <div class="user">
                   
                    <p class="app-sidebar__user-name"></i><?php echo $name; ?></p>
                  
                        
    
                    
                </div>
                   
                   
                </div>


            </div>

           




        </div>






    </div>
    <script>
        function toggleMenu() {
            let toggle = document.querySelector('.toggle');
            let navigation = document.querySelector('.navigation');
            let main = document.querySelector('.main');
            toggle.classList.toggle('active');
            navigation.classList.toggle('active')
            main.classList.toggle('active')

        }
    </script>

</body>

</html>