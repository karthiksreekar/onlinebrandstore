<?php
include 'db.php';
session_start(); 
error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:login.php');
}
$sql = mysqli_query($conn,"SELECT * from tbl_reg where regid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
 
}
?>


<!doctype html>
<html lang="en">
  <head>
  	<title>Table 06</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="orders_assets/css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-4">
					<h2 class="heading-section">View Orders</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
                            <th>User ID<th>
						    <th>Product</th>  
						      <th>Price</th>
					         <th>Quantity</th>
						      <th>Total</th>
                              <th>Status</th>
                              <th> <th>

						    </tr>
						  </thead>
						  <tbody>
                          <?php
                  $sql2 = "SELECT * from tbl_order";
                  $price=mysqli_query($conn,$sql2);
                  $cart = mysqli_fetch_array($price);
                  $total=$cart['price'];
                  $status=$cart['status'];
            $result = mysqli_query($conn,"SELECT tbl_cart.id,tbl_cart.userid,tbl_cart.price,tbl_cart.size,tbl_cart.quantity,tbl_cart.total_price, tbl_cart.pro_id,tbl_products.product_name, tbl_products.product_image,tbl_products.product_company FROM tbl_cart LEFT JOIN tbl_products ON tbl_cart.pro_id = tbl_products.pro_id ");
                                while ($raw = mysqli_fetch_array($result)){
                                     ?>
						    <tr class="alert" role="alert">
                            <td clas="email"><?php echo $raw['userid']; ?></td>
            
						    	<td class="email">
						    		<div class="img" style="background-image: url(productimages/<?php echo $raw['pro_id']; ?>/<?php echo $raw['product_image']; ?>);"></div>
						    	</td>
                                 
						      <td>
						      	<div class="email">
						      		<span><?php echo $raw['product_name']; ?> </span>
						    
						      	</div>
						      </td>
						      <td><?php echo $raw['price']; ?></td>
                            
						      <td class="quantity">
					        	<div class="input-group">
				             	<input type="text" name="quantity" class="quantity form-control input-number" value="<?php echo $raw['quantity']; ?>" min="1" max="100">
				          	</div>
				          </td>
				          <td><?php echo $raw['total_price']; ?></td>
                          <td><input type="text" name="status" value="placed"></td>
						      <td>
                              
						      	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				            	<span aria-hidden="true"><i class="fa fa-close"></i></span>
				          	</button>
				        	</td>
                                <?php } ?>  
                               
						    </tr>
                         

						   

						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

