<?php
include 'db.php';
session_start(); 
error_reporting(0);
$uid = $_SESSION['UserID'];
if($_SESSION['UserID']==""){
  header('location:page-login.php');
}
$sql = mysqli_query($conn,"SELECT * from tbl_reg where regid='$uid'");
while($row=mysqli_fetch_array($sql)){
  $name = $row['name'];
}
if(isset($_POST['submit'])){
	$fit=$_POST['fit'];
    $color=$_POST['color'];
    $size=$_POST['size'];
	$fabric=$_POST['fabric'];
	$pattern=$_POST['pattern'];
    $collar=$_POST['collar'];
    $sleeve=$_POST['sleeve'];

	$sql = mysqli_query($conn,"INSERT INTO `tbl_custom`(`userid`,`fit`, `color`, `fabric`,`size`,`pattern`,`sleeve`,`collar`,`type`) VALUES ('$uid','$fit','$color','$fabric','$size','$pattern','$sleeve','$collar','shirt')");
    echo"<script>alert('Details Added');</script>";
}



?><!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Denimology Dept.</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
    <link rel="apple-touch-icon" href="logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i"
        rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- Main CSS-->
    <link href="css_insert/main.css" rel="stylesheet" media="all">
    
    

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>



    <!-- Start Main Top -->
    <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="text-slid-box">
                        
                    </div>
                </div>
             
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php"><img src="images/logo.jpg" class="logo" alt="" style="height: 124px;width: 147px;"></a>
                    <div class="brand_name" style="float: right;margin-top: 34px;">
                    <h2 style="font-size:30px;font-family: 'Montserrat';font-weight: 600;">Denimology<br>Dept.<h2>
                    
                    </div>
                    
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                    <li class="nav-item"><a class="nav-link" href="index.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Home</a></li>
                        <li class="dropdown megamenu-fw">
                        <li class="nav-item"><a class="nav-link" href="shop.php"style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Shop</a></li>
                            
                        </li>
                        
                        <li class="nav-item"><a class="nav-link" href="cart.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Cart</a></li>
                        <li class="nav-item"><a class="nav-link" href="customize.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Customize</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php" style="font-size: 19px;font-weight: 700;font-family: 'Montserrat';">Log Out</a></li>
                      
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
               
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
           
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
 
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box" style="background-image: url('https://qph.fs.quoracdn.net/main-qimg-853e77395bbedd76c579dc9fbae213cd');">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 style="font-size: 45px;font-weight: 900; padding-left: 80px;">Denimology Dept. </h2>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="page-wrapper bg-gra-03 p-t-45 p-b-50" style="background-color: #f5f5f5;">
        <div class="wrapper wrapper--w790">
            <div class="card card-5">
                <div class="card-heading" style="background-color: #d33b33;">
                    <h2 class="title">ADD DETAILS</h2>
                </div>
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                       
                        <div class="form-row">
                            <div class="name">Select Fit</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="fit" name="fit" class="form-control" >
                                        <option value="regular">Regular</option>
                                        <option value="slim">Slim</option>
                                        <option value="oversized">Oversized</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">colour</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="color" name="color" class="form-control" >
                                        <option value="white">White</option>
                                        <option value="black">Black</option>
                                        <option value="navyblue">Navyblue</option>
                                        <option value="yellow">Yellow</option>
                                        <option value="red">Red</option>
                                        <option value="green">Olive Green</option>
                                        <option value="maroon">Maroon</option>
                                        <option value="brown">Brown</option>
                                        <option value="grey">Grey</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                         
                        <div class="form-row">
                            <div class="name">Fabric</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="fabric" name="fabric" class="form-control">
                                        <option value="denim">Denim</option>
                                        <option value="cotton">cotton</option>
                                        <option value="coudroy">coudroy</option>
                                        <option value="linen">linen</option>
                                        <option value="lycra">lycra</option>
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Size</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="size" name="size"  class="form-control">
                             
                                        <option value="small">small</option>
                                        <option value="medium">Medium</option>
                                        <option value="large">Large</option>
                                        <option value="xlarge">Xlarge</option>
                                        <option value="xxlarge">XXlarge</option>
                                        <option value="xxxlarge">XXXlarge</option>

                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Pattern</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="pattern" name="pattern" class="form-control">
                                       
                                        <option value="solid">solid</option>
                                        <option value="floral">floral</option>
                    
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Sleeve Length</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="sleeve" name="sleeve" class="form-control">
                                        <option value="half">Half Sleeve</option>
                                        <option value="full">Full Sleeve</option>
                                      
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Collar Type</div>
                            <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search" style=" width: 214px;">
                                    <select id="collar" name="collar" class="form-control">
                                        <option value="chinese">Chinese</option>
                                        <option value="normal">Normal</option>
                                        <option value="flared">flared</option>
                                        
                                        </select>
                                        <div class="select-dropdown"></div>
                                    </div>
                                </div>
                            </div>
                        </div>



                       
                       
                




                        <div>
                            <button class="btn btn--radius-2 btn--red" type="submit" name="submit">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>



    <!-- Start Footer  -->
   <?php include 'footer.php' ?>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>